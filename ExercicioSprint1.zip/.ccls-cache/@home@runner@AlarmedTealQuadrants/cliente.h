#include <iostream>
using namespace std;

class Cliente{
private :
  int         IMEI;
  std::string Login;  
public:  
  Cliente();
  Cliente(int IMEI, std::string nome);
  string getLogin() const;
  int getIMEI() const;
};