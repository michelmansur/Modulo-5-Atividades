#include "cliente.h"

Cliente::Cliente(){
  this->IMEI   = -1;
  this->Login = "";
};  
Cliente::Cliente(int ra, std::string nome){
  this->IMEI    = ra;
  this->Login  = nome;
}
string Cliente::getLogin() const {
  return Login;
}
int Cliente::getIMEI() const{
  return IMEI;
}