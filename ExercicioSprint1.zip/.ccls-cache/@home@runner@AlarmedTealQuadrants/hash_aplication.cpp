#include "hash.h"
#include <iostream>

using namespace std;

int main() {
  Hash clientesHash(10);
  int ras[7] = {12704, 31300, 1234, 49001, 52202, 65606, 91234};
  string nomes[7] = {"NPC1", "NPC2", "NPC3", "NPC4", "NPC5", "NPC5", "NPC6"};

  for (int i = 0; i < 7; i++) {
    Cliente cliente = Cliente(ras[i], nomes[i]);
    clientesHash.insertItem(cliente);
  }
  clientesHash.print();
  cout << "------------------------------" << endl;

  Cliente cliente(12704, "");
  bool found = false;
  clientesHash.retrieveItem(cliente, found);
  cout << cliente.getLogin() << " -> " << found << endl;

  cout << "------------------------------" << endl;

  clientesHash.deleteItem(cliente);
  clientesHash.print();
  cout << "Fim" << endl;
}

// Casos de teste:

// No teste de inserção, é necessário adicionar 10 elementos na tabela Hash, e
// consequentemente, verificar se os elementos estão inseridos corretamente..

// No teste de busca, é necessario buscar um elemento no meio da tabela que está
// composto por um R.A conhecido.

// No teste de busca invalida é necessario buscar um teste de um elemento que
// não existe, e logo em seguida, verificar se não encontrou realmente

// No teste de remoção é necessario remover um elemento da tabela hash e verificar se ele foi
// removido corretamente.

// No teste de resolução de colisão, é necessario adicionar vaior elementos na tabela com o mesmo R.A, para que ocorra colisões e verificar se a tabela está solucionando corretamente.